package com.example.aplikasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
