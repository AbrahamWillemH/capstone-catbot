import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:aplikasi/screens/profil_screen.dart';

class HomeScreen extends StatefulWidget {
  final String email;
  final String password; // Menambahkan parameter password

  const HomeScreen({super.key, required this.email, required this.password});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();
  File? _image;

  // Fungsi untuk membuka kamera
  Future<void> _openCamera() async {
    try {
      final XFile? pickedImage = await _picker.pickImage(
        source: ImageSource.camera,
        maxWidth: 800,
        maxHeight: 600,
      );
      if (pickedImage != null) {
        setState(() {
          _image = File(pickedImage.path);
        });
      }
    } catch (e) {
      print("Error membuka kamera: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF075E54),
        title: const Text('Halaman Utama'),
      ),
      body: Container(
        height: double.infinity, // Memastikan tinggi mencakup seluruh layar
        width: double.infinity,  // Memastikan lebar mencakup seluruh layar
        decoration: const BoxDecoration(
          color: Color(0xFFD0F0C0), // Warna hijau tea
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 20),
              const Text(
                'Sistem Deteksi Penyakit Kucing',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              // Area untuk menampilkan gambar yang diambil
              if (_image != null)
                Image.file(
                  _image!,
                  height: 300,
                  width: 300,
                  fit: BoxFit.cover,
                ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: const Color.fromARGB(255, 7, 94, 84),
        selectedItemColor: const Color.fromARGB(255, 255, 255, 255),
        unselectedItemColor: const Color.fromARGB(255, 255, 255, 255),
        onTap: (index) {
          switch (index) {
            case 0:
              _openCamera();
              break;
            case 1:
              Navigator.pushNamed(context, '/chatbot');
              break;
            case 2:
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProfileScreen(
                    email: widget.email,
                    username: widget.password, // Mengirimkan password sebagai username
                    phoneNumber: '081234567890', // Nomor telepon contoh
                    photoUrl: 'https://example.com/profile.jpg', // URL foto profil
                    dateOfBirth: '01-01-1990', // Tanggal lahir
                    address: 'Jakarta, Indonesia', // Alamat
                    profession: 'Developer', // Pekerjaan
                  ),
                ),
              );
              break;
          }
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.photo_library),
            label: 'Unggah File',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: 'Chat Bot',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}
